<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" href="pro.css">
<link rel="stylesheet" href="menü.css">
<link rel="stylesheet" href="yatay_menü.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,400i,700">
  <!-- Code by Angela Delise  https://codepen.io/angeladelise/pen/OJVePqz
 -->
 <style>
     .logo img{
  object-fit: cover;
  border-radius: 50%;
}
.logo img{
  height: 50px;
  width: 50px;
  
 </style>
  <style>
      .logout {
  display: block;
  background: #333;
  color: #fff;
  outline: none;
  border: none;
  padding: 7px 15px;
  text-decoration: none;
  border-radius: 5px;
  font-size: 17px;
}
body{
    height: 100vh;
    background: linear-gradient(
        135deg,
        #ffffff,
#ffffff
    );
}
  </style>


<body>
     
  <div class="wrapper">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          <img src="php/images/<?php echo $row['img']; ?>" alt="">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
        <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
        
      </header>
      
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com" class="logout">Anasayfa</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/profil.php" class="logout">Profil</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/Dersler.php" class="logout">Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/canl%C4%B1_dersler.php" class="logout">Canlı Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Sınavlar</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Kütüphane</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Çalışmalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Dosyalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Site hakında bilgi</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">MFŞ MESAJ</a>
      </header>
        <header>
          <center>
        <a href="https://muhamedfatihbro13.000webhostapp.com/e%C4%9Flenme_vakti.php" class="logout">oyunlar</a>
        </center>
      </header>
 <li>
  <center>
  <h1>MFŞ EGİTİM</h1>
    
      </center>
     
      </li>
      </div>
      
    </section>
    
  </div>

  <script src="javascript/users.js"></script>
  <script src="menü.js"></script>
  <style> 
	img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
	 display:none!important;
	}
</style>
</body>
</html>