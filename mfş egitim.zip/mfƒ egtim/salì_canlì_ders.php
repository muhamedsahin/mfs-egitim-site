<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" href="pro.css">
<link rel="stylesheet" href="menü.css">
<link rel="stylesheet" href="yatay_menü.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,400i,700">
  <!-- Code by Angela Delise  https://codepen.io/angeladelise/pen/OJVePqz
 -->
 <style>
     .logo img{
  object-fit: cover;
  border-radius: 50%;
}
.logo img{
  height: 50px;
  width: 50px;
  
 </style>
  <style>
      .logout {
  display: block;
  background: #333;
  color: #fff;
  outline: none;
  border: none;
  padding: 7px 15px;
  text-decoration: none;
  border-radius: 5px;
  font-size: 17px;
}
  </style>
<style>
 
	body { background-image: url('https://lh3.googleusercontent.com/lO4fhLtJkUDIyXNr5geHXRy-IFh91qLQZ99Ue-UlwtwiOKaC6wAeG3Y0c8XQqj4dJ0aeLp-GFoZbaRMj4Qr5jw94-psRH2khWFUOZtJnkia1hopkqbpHWkqJ_XrjyKv23A12vB71Wl2IGL6iMlQccBTzgKVi-4SrajzDQZVHiZBE914LJsTte8uxCH9Xndb_MCrOQ0YmMsucl9rRpeZi82qm-I7a8PzOL7jn7r65LCGWYJb_6dpW3X-FYcpYkbstwzZHXO7vJZQv2FsAe8L1kX4cRz3PDQ8O7EBw-Nvllt-VRIE43GYhag-pyWbPG_6d_FBZxE3kwaRQMzU8PWqmZYwOqU1A-cxHlvGeHzm8qKX2RI1FI4_a9YEa6VCVGwm67tuFpcsFlij6OKj1cINxu2-K0v6OyY3ThgUkFTLtMpFyS88c4v3cWmQwnF8aigS44s90EJa0jAh1taOHFkp7aNAy4rT6mjD10QpESvP_gcpId29SgfSeOhUI3DqaU_8OSMJbl309wy_q0tBFimjO3lohrRAEwYigHGu3pzh25DnnpBCRCsV5JbCO79jDYHLWf1cM9e4xXqkn3XN09hMzZzZ4h9fXVwoqAaIjGLC7JrJS1blhuNkM4tL4ulFahD-e86TfOoz7WR8hnIbsS-H_mmM-nng0nT-9y2sqnGj3khwieC_21v619AqIPrB6jkT-ty0Rh7eXMgHSS0VUyURb2UA=w710-h444-no?authuser=0'); }   
</style>

<body>
    
 
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
        
        
     
      
    </section>
    
  </div>
   <div class="page-wrapper">
        <header>
            
            <img src="https://github.com/muhamedsahin/resimlerim/blob/main/2020-01-12.png?raw=true" alt="MFŞ"/>

        </header>
    </div>
    <!-- Side Menu -->
    <nav class="side-menu">
        <ul>
            <li class="logo">
                <a href="#"><i> <img src="php/images/<?php echo $row['img']; ?>" alt="" width="100" height="100"></i> <font  color = “40E0D0”><?php echo $row['fname']. " " . $row['lname'] ?></font> </a>
                    <i><a href="#"><img class="menu-toggle" src="arrow-right.png" alt=""></a></i>
                </li>
                <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
            <li class="search">
                <a class="item list" href="#">
                    <i><img src="search.png" alt=""></i>
                    <span><form><input type="text" placeholder="Search"></form></span>
                </a>
            </li>
            
            <li>
                <a class="item list" href="https://muhamedfatihbro13.000webhostapp.com/users.php">
                    <i><img src="dashboard.png" alt="">
                    </i> <span class="text">Ana Sayfa</span>
                </a>
            </li>
            <li>
                <a class="item list" href="https://muhamedfatihbro13.000webhostapp.com/users.php">
                    <i><img src="products.png" alt=""></i> 
                    <span class="text">Products</span>
                </a>
            </li>
            <li>
                <a class="item list" href="#">
                    <i><img src="campaigns.png" alt=""></i> 
                    <span class="text">Campaigns</span>
                </a>
            </li>
            <hr>
            <li>
                <a class="item list" href="#">
                    <i><img src="sales.png" alt=""></i> 
                    <span class="text">Sales</span>
                </a>
            </li>
            <li>
                <a class="item list" href="#">
                    <i><img src="discount.png" alt=""></i> 
                    <span class="text">Discount</span>
                </a>
            </li>
            <li>
                <a class="item list" href="#">
                    <i><img src="payouts.png" alt=""></i> 
                    <span class="text">Payouts</span>
                </a>
            </li>
            <hr>
            <li>
                <a class="item list" href="#">
                    <i><img src="chat.png" alt=""></i> 
                    <span class="text">Chat</span>
                </a>
            </li>
            <li>
                <a class="item list" href="#">
                    <i><img src="settings.png" alt=""></i>
                    <span class="text">Settings</span>
                </a>
            </li>
            <hr>
            <li>
                <a class="item list" href="#">
                    <i><img src="new_product.png" alt=""></i> 
                    <span class="text">New Product</span>
                </a>
            </li>
        </ul>
    </nav>

  
       <center>
       
       
       
       
       
       
       
       

      </center>
    

  <script src="javascript/users.js"></script>
  <script src="menü.js"></script>
  <style> 
	img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
	 display:none!important;
	}
</style>
</body>
</html>