<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" href="pro.css">
<link rel="stylesheet" href="menü.css">
<link rel="stylesheet" href="yatay_menü.css">
<style>
    body{
    height: 100vh;
    background: linear-gradient(
        135deg,
        #54d9d9,
        #2eaebf
    );
}
</style>
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,400i,700">
  <!-- Code by Angela Delise  https://codepen.io/angeladelise/pen/OJVePqz
 -->
 <style>
     .logo img{
  object-fit: cover;
  border-radius: 50%;
}
.logo img{
  height: 50px;
  width: 50px;
  
 </style>
<style>
    * {
  margin: 0;
  padding: 0;
}

body {
  display: flex;
  justify-content: center;
  
  align-items: center;
  min-height: 100vh;
  background: #240229;
}

.loader {
     list-style-type:none; 
  position: relative;
  width: 200px;
  height: 200px;
  border: 4px solid #240229;
  overflow: hidden;
  border-radius: 50%;
  box-shadow: -5px -5px 5px rgba(255, 255, 255, 0.1), 10px 10px 10px rgba(0, 0, 0, 0.4), inset -5px -5px 5px rgba(255, 255, 255, 0.2), inset 10px 10px 10px rgba(0, 0, 0, 0.4);
}

.loader:before {
  content: "";
  position: absolute;
  top: 25px;
  left: 25px;
  right: 25px;
  bottom: 25px;
  z-index: 10;
  background: #ffffff00;
  border-radius: 50%;
  border: 2px solid #ffffff00;
  box-shadow: inset -2px -2px 5px rgba(255, 255, 255, 0.2), inset 3px 3px 5px rgba(0, 0, 0, 0.5);
}

.loader span {
  position: absolute;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background-image: linear-gradient(-225deg, #ff057c 0%, #8d0b93 50%, #321575 100%);
  filter: blur(20px);
  z-index: -1;
  animation: animate 0.5s linear infinite;
}

@keyframes animate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

</style>     
<style>
 
	body { background-image: url(''); }   
</style>

<body>
        
  <div class="wrapper">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          <img src="php/images/<?php echo $row['img']; ?>" alt="">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
        <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
        
      </header>
      
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com" class="logout">Anasayfa</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/profil.php" class="logout">Profil</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/Dersler.php" class="logout">Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/canl%C4%B1_dersler.php" class="logout">Canlı Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Sınavlar</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Kütüphane</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Çalışmalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Dosyalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Site hakında bilgi</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">MFŞ MESAJ</a>
      </header>
 <li>
  <center>
  <h1>MFŞ EGİTİM</h1>
    
      </center>
     
      </li>
      </div>
      
    </section>
    
  </div>
 
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
        
        
     
      
    </section>
    
  </div>
   <div class="page-wrapper">
        <header>
            
            <center>
            <li class="mfş">
                <a href="#"> <img src="php/images/<?php echo $row['img']; ?>" alt="" width="100" height="100"> </a>
                    
                </li>
           </center>
        </header>
    </div>

 <div class="loader">
        <span></span>
    </div>
  <style>
     .mfş img{
  object-fit: cover;
  border-radius: 50%;
   list-style-type:none; 
}
.li
{
 list-style-type:none;
}
.mfş img{
  height: 137px;
  width: 137px;
   position: absolute;

      left: 175px;
      top: -230%;
  
 </style>
 <center>
   
 <li>
 <h1>adınız</h1>
 <div class=ad>
     <font  color = “40E0D0”><?php echo $row['fname']. " " . $row['lname'] ?></font> 
     </div>
     </li>
     </center>
      <style>
          .ad
          {
              padding:0;
    margin:0;
    top:40%;
    left:0%;
          }
          </style>
      </style>
    

  <script src="javascript/users.js"></script>
  <script src="menü.js"></script>
  <style> 
	img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
	 display:none!important;
	}
</style>
</body>
</html>