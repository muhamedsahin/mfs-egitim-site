<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" href="pro.css">

<style>

ul {
    padding: 0;
    list-style-type: none;
}

li {
    font-size: 25px;
    width: 8em;
    height: 2em;
    color: orange;
    border-left: 0.08em solid;
    position: relative;
    margin-top: 0.8em;
    cursor: pointer;
}

li::before,
li::after
 {
    content: '';
    position: absolute;
    width: inherit;
    border-left: inherit;
    z-index: -1;
}

li::before {
    height: 80%;
    top: 10%;
    left: calc(-0.15em - 0.08em * 2);
    filter: brightness(0.8);
}

li::after {
    height: 60%;
    top: 20%;
    left: calc(-0.15em * 2 - 0.08em * 3);
    filter: brightness(0.6);
}

li span {
    position: relative;
    height: 120%;
    top: -10%;
    box-sizing: border-box;
    border: 0.08em solid;
    background-color: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: sans-serif;
    text-transform: capitalize;
    transform: translateX(calc(-0.15em * 3 - 0.08em * 2));
    transition: 0.3s;
}

li:hover span {
    transform: translateX(0.15em);
}
</style>
<body>
  <div class="wrapper">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          <img src="php/images/<?php echo $row['img']; ?>" alt="">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
        <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
        
      </header>
       </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com" class="logout">Anasayfa</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/profil.php" class="logout">Profil</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/Dersler.php" class="logout">Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/canl%C4%B1_dersler.php" class="logout">Canlı Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Sınavlar</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Kütüphane</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Çalışmalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Dosyalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Site hakında bilgi</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">MFŞ MESAJ</a>
      </header>    
      </div>
       <div class="animation-area">
		<ul class="box-area">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
 <center>
  <ul>
    <li><span>cuma 1.ders</span></li>
    <li><span>cuma 2.ders</span></li>
    <li><span>cuma 3. ders</span></li>
    <li><span>cuma 4.ders</span></li>
  </ul>
  <ul>
    <li><span>cuma 5. ders</span></li>
    <li><span>cuma 6.ders</span></li>
    <li><span>cuma 7.ders</span></li>
    <li><span>cuma 8.ders</span></li>
  </ul>
  </center>

	
  
            
     
      
         
  
      
    </section>
  </div>

  <script src="javascript/users.js"></script>
  <style> 
	img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
	 display:none!important;
	}
</style>
</body>
</html>