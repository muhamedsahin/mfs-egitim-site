<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" href="pro.css">
<link rel="stylesheet" href="menü.css">
<link rel="stylesheet" href="yatay_menü.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,400i,700">
  <!-- Code by Angela Delise  https://codepen.io/angeladelise/pen/OJVePqz
 -->
 <style>
     .logo img{
  object-fit: cover;
  border-radius: 50%;
}
.logo img{
  height: 50px;
  width: 50px;
  
 </style>
 <style>
    * { margin: 0; padding: 0; font-family: consolas; }
   .kuran{ 
    
                 position: absolute;


      top: 55px;
      right: 52%;

      z-index: 1;}
      .kuran img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
     .beden{ 
                  position: absolute;


      top: 55px;
      right: 27%;

      z-index: 1;}
      .beden img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
      .dinkültürü{ 
                     position: absolute;


      top: 55px;
      right: 1px;

      z-index: 1;}
      .dinkültürü img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
       .fen{ 
    
           position: absolute;


      top: 306px;
      right: 712px;

      z-index: 1;}
      .fen img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
         .ing{ 
    
           position: absolute;


      top: 306px;
      right: 27%;

      z-index: 1;}
      .ing img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
     .arapca{ 
    
           position: absolute;


      top: 306px;
      right: 1%;

      z-index: 1;}
      .arapca img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
     .mat{ 
    
           position: absolute;


      top: 546px;
      right: 52%;

      z-index: 1;}
      .mat img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
       .siyer{ 
    
           position: absolute;


      top: 546px;
      right: 27%;

      z-index: 1;}
      .siyer img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
           .sos{ 
    
           position: absolute;


      top: 796px;
   right: 27%;

      z-index: 1;}
      .sos img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
       .türce{ 
    
           position: absolute;


      top: 546px;
    right: 1%;

      z-index: 1;}
      .türce img{ 
          border-radius:
16% 16% 16% 16% / 16% 16% 16% 16%

    }
    a { 
        position: relative;
        display: inline-block;
        padding: 10px 30px;
        text-decoration: none;
        text-transform: uppercase;
        font-weight: 500; 
        letter-spacing: 2px; 
        color: #5a84a2;
        font-size: 18px; 
        border-radius: 40px; 
        box-shadow: -2px -2px 8px rgba(255, 255, 255, 1), -2px -2px 12px rgba(255, 255, 255, 0.5), inset 2px 2px 4px rgba(255, 255, 255, 0.1), 2px 2px 8px rgba(0, 0, 0, 0.15); } a:hover { box-shadow: inset -2px -2px 8px rgba(255, 255, 255, 1), inset -2px -2px 12px rgba(255, 255, 255, 0.5), inset 2px 2px 4px rgba(255, 255, 255, 0.1), inset 2px 2px 8px rgba(0, 0, 0, 0.15);
        }
    a:hover span 
    { display: inline-block; transform: scale(0.98); 
        
    }
    li
    {
        list-style-type:none;
    }
    </style>
  <style>
      .logout {
  display: block;
  background: #333;
  color: #fff;
  outline: none;
  border: none;
  padding: 7px 15px;
  text-decoration: none;
  border-radius: 5px;
  font-size: 17px;
}
body{
    height: 100vh;
    background: linear-gradient(
        135deg,
        #ffffff,
#ffffff
    );
}
  </style>


<body>
     
  <div class="wrapper">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          <img src="php/images/<?php echo $row['img']; ?>" alt="">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
        <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
        
      </header>
      
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com" class="logout">Anasayfa</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/profil.php" class="logout">Profil</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/Dersler.php" class="logout">Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/canl%C4%B1_dersler.php" class="logout">Canlı Dersler</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Sınavlar</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Kütüphane</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Çalışmalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Dosyalarım</a>
      </header>
      <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">Site hakında bilgi</a>
      </header>
       <header>
        <a href="https://muhamedfatihbro13.000webhostapp.com/MFS_MESAJ.php" class="logout">MFŞ MESAJ</a>
      </header>
        <header>
          <center>
        <a href="https://muhamedfatihbro13.000webhostapp.com/e%C4%9Flenme_vakti.php" class="logout">oyunlar</a>
        </center>
      </header>
 <li>
  <center>
  <h1>MFŞ EGİTİM</h1>
    
      </center>
     
      </li>
      </div>
      <div class=kuran>
      <center >
      <a href="/dersler/kuran.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/345250fe977898d29ae938d0645258a9.png" alt="Örnek Resim"/>
      <h2>kuran</h2>
</span></a>
      </center>
      </div>
         <div class=beden>
      <center >
      <a href="/dersler/beden.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/84bf4a7c9a46033639648fc7dd0e36cc.png" alt="Örnek Resim"/>
      <h2>beden</h2>
</span></a>
      </center>
      </div>
         <div class=dinkültürü>
      <center >
      <a href="/dersler/dinkültürü.php"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/58e4b64bdb7da2c302fa87104aa0f49f.png" alt="Örnek Resim"/>
      <h2>dinkültürü</h2>
</span></a>
      </center>
      </div>
            <div class=fen>
      <center >
      <a href="/dersler/fen.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/a2546a1aaff0b112f8f3db9fd2e3f067.png" alt="Örnek Resim"/>
      <h2>fen</h2>
</span></a>
      </center>
      </div>
            <div class=ing>
      <center >
      <a href="/dersler/ingilizce.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/c7d06160d198694266f717eb0bdf1f23.png" alt="Örnek Resim"/>
      <h2>ing</h2>
</span></a>
      </center>
      </div>
          <div class=arapca>
      <center >
      <a href="/dersler/arapca.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/c0a21a29293b20dbbc5e43ea74dcb868.png" alt="Örnek Resim"/>
      <h2>arapca</h2>
</span></a>
      </center>
      </div>
         <div class=mat>
      <center >
      <a href="/dersler/matematik.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/9ccb2da2754516587b6d1609a1516ea0.png" alt="Örnek Resim"/>
      <h2>matematik</h2>
</span></a>
      </center>
      </div>
         <div class=siyer>
      <center >
      <a href="/dersler/siyer.html"><span><img width="260" height="150" src="https://github.com/muhamedsahin/resimler-mf-egitim.github.io/blob/main/345250fe977898d29ae938d0645258a9.png?raw=true" alt="Örnek Resim"/>
      <h2>siyer</h2>
</span></a>
      </center>
      </div>
          <div class=sos>
      <center >
      <a href="/dersler/sos.html"><span><img width="260" height="150" src="https://github.com/muhamedsahin/resimler-mf-egitim.github.io/blob/main/cd42ec044af2a6841a5965a81468eee3.png?raw=true" alt="Örnek Resim"/>
      <h2>sosyal</h2>
</span></a>
      </center>
      </div>
          <div class=türce>
      <center >
      <a href="/dersler/türk.html"><span><img width="260" height="150" src="https://raw.githubusercontent.com/muhamedsahin/resimler-mf-egitim.github.io/main/67b09ec260e93b2b4ea5392ef5ffbd2c.png" alt="Örnek Resim"/>
      <h2>türkce</h2>
</span></a>
      </center>
      </div>
    </section>
    
  </div>

  <script src="javascript/users.js"></script>
  <script src="menü.js"></script>
  <style> 
	img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
	 display:none!important;
	}
</style>
</body>
</html>